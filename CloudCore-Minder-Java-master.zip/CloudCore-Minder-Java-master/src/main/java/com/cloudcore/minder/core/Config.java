package com.cloudcore.minder.core;

public class Config {
    /* Constant Fields */

    public static final String TAG_MINDER = "Minder";

    public static final String TAG_GALLERY = "Gallery";
    public static final String TAG_BANK = "Bank";
    public static final String TAG_FRACKED = "Fracked";

    // name of file which will be placed in command folder
    public static String TAG_file_name = "minder";
    
    public static final String TAG_CLOUD_COIN = "CloudCoin";
    public static final String TAG_COMMAND = "Command";
    public static final String TAG_MINDER_DEFAULT = "Minder";
    public static final String TAG_LOGS = "Logs";
    
    
    public static final String TAG_ACCOUNTS = "Accounts";
    public static final String TAG_PASSWORDS = "Passwords";
    
    /* Fields */
    public static int nodeCount = 25;
}
